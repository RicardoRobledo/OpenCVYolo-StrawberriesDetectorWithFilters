import os
import xml.etree.ElementTree as ET

# Función para convertir las coordenadas a formato YOLO (normalizadas)


def convert_to_yolo_format(xmin, ymin, xmax, ymax, img_width, img_height):
    # Convertir a formato YOLO (relativo)
    x_center = (xmin + xmax) / 2 / img_width
    y_center = (ymin + ymax) / 2 / img_height
    width = (xmax - xmin) / img_width
    height = (ymax - ymin) / img_height

    return x_center, y_center, width, height

# Función para procesar todos los archivos .xml en la carpeta de anotaciones


def process_annotations(xml_folder, output_folder):
    # Iterar sobre todos los archivos .xml en la carpeta de anotaciones
    for xml_file in os.listdir(xml_folder):
        if xml_file.endswith('.xml'):
            xml_path = os.path.join(xml_folder, xml_file)
            # Parsear el archivo XML
            tree = ET.parse(xml_path)
            root = tree.getroot()

            # Obtener las dimensiones de la imagen desde el XML
            size = root.find('size')
            img_width = int(size.find('width').text)
            img_height = int(size.find('height').text)

            # Crear la ruta del archivo de salida en formato YOLO
            txt_filename = os.path.splitext(xml_file)[0] + '.txt'
            txt_path = os.path.join(output_folder, txt_filename)

            with open(txt_path, 'w') as txt_file:
                # Leer los objetos del archivo XML
                for obj in root.findall('object'):
                    # Obtener el nombre de la clase
                    class_name = obj.find('name').text

                    # Aquí debes mapear las clases a un número (índice)
                    # Por ejemplo, si solo tienes 2 clases, mapea 'FresaMadura' a 0 y 'FresaInmadura' a 1
                    class_id = 0 if class_name == "FresaMadura" else 1  # Ejemplo de mapeo de clases

                    # Obtener las coordenadas del bounding box
                    bndbox = obj.find('bndbox')
                    xmin = float(bndbox.find('xmin').text)
                    ymin = float(bndbox.find('ymin').text)
                    xmax = float(bndbox.find('xmax').text)
                    ymax = float(bndbox.find('ymax').text)

                    # Convertir a formato YOLO
                    x_center, y_center, width, height = convert_to_yolo_format(
                        xmin, ymin, xmax, ymax, img_width, img_height)

                    # Escribir la anotación en el archivo .txt (formato YOLO)
                    txt_file.write(
                        f"{class_id} {x_center} {y_center} {width} {height}\n")

            print(f"Archivo de etiquetas YOLO guardado: {txt_path}")


# Carpeta donde se encuentran los archivos .xml
xml_folder = 'Annotations'  # Ajusta según la ruta de tu carpeta de anotaciones
# Carpeta donde se guardarán los archivos .txt (etiquetas YOLO)
output_folder = 'YoloLabels'

# Crear la carpeta de salida si no existe
if not os.path.exists(output_folder):
    os.makedirs(output_folder)

# Procesar las anotaciones
process_annotations(xml_folder, output_folder)

print("Conversión de anotaciones a formato YOLO completada.")
